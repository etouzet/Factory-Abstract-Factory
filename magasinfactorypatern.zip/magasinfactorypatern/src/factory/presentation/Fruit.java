package factory.presentation;

public interface Fruit {
    void etre_manger(Fruit fruit);
    void pourrir();
}
