package factory.presentation;

public abstract class CreateurFruit {
    public abstract Fruit fabrique();
}