package abstractfactory;

public interface Pomme {
    void est_manger();
    void pourrir();
}
