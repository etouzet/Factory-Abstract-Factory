package abstractfactory;

public interface Orange {
    void est_manger();
    void pourrir();

}
