package abstractfactory;

public interface Createur {
    Pomme creationPomme();
    Orange creationOrange();


}